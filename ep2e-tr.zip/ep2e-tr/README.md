# Overview

* Not intended for use beyond our private, not pulished/streamed/... in any way table game. Just publicly hosted for repository based collaboration purposes.
* Repo-wise the license as specified applies for our own work, just be aware of the above, neither fit not intended for anyone else's use.


# Attributions

* Free icons by https://www.flaticon.com/authors/kiranshastry